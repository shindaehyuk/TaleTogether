package com.kong.authtest.user.repository;

public interface UserRepositoryCustom {
}
