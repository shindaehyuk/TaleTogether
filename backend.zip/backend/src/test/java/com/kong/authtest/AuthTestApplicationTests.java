package com.kong.authtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
